### >mysql utf8问题

  
>see [MySQL and UTF-8 — no more question marks!][1] 使用securecrt登录服务器, 其appearance > character encoding的值为utf8 服务器locale为utf8 <pre class="code">$ locale
LANG=en_US.UTF-8
LANGUAGE=en_US:en
LC_CTYPE="en_US.UTF-8"
LC_NUMERIC="en_US.UTF-8"
LC_TIME="en_US.UTF-8"
LC_COLLATE="en_US.UTF-8"
LC_MONETARY="en_US.UTF-8"
LC_MESSAGES="en_US.UTF-8"
LC_PAPER="en_US.UTF-8"
LC_NAME="en_US.UTF-8"
LC_ADDRESS="en_US.UTF-8"
LC_TELEPHONE="en_US.UTF-8"
LC_MEASUREMENT="en_US.UTF-8"
LC_IDENTIFICATION="en_US.UTF-8"
LC_ALL=
</pre> /etc/mysql/my.cnf中的client和mysqld的default-character-set 均未设置，使用编译默认值 latin1 

<pre class="code">$ mysql -utest  -e 'show variables like "%char%"'  
+--------------------------+----------------------------+
| Variable_name            | Value                      |
+--------------------------+----------------------------+
| character_set_client     | latin1                     |
| character_set_connection | latin1                     |
| character_set_database   | latin1                     |
| character_set_filesystem | binary                     |
| character_set_results    | latin1                     |
| character_set_server     | latin1                     |
| character_set_system     | utf8                       |
| character_sets_dir       | /usr/share/mysql/charsets/ |
+--------------------------+----------------------------+
</pre> data.sql (文件编码为utf8)创建utf8编码的数据库和表并往其中插入中文数据 

<pre class="code">$ cat data.sql
DROP DATABASE IF EXISTS test;
CREATE DATABASE test  DEFAULT CHARACTER SET utf8;
CREATE TABLE test.documents
(
      id             INTEGER PRIMARY KEY NOT NULL AUTO_INCREMENT,
      title           VARCHAR(255) NOT NULL
);
REPLACE INTO test.documents ( id, title) VALUES  ( 1,  '中' );

$ cat test0.sh
mysql -utest &lt;data .sql mysql="" utest="" test="" e="" select="" from="" sh="" title="" c3a4c2b8c2ad="">&lt;/data></pre> hex(title)为存在数据库中的实际值的hex编码，无论编码怎么变化，它的值始终不变 插入 由于character\_set\_client为latin1，在data.sql中，"中"的字节流"E4B8AD"被解释为三个latin1字符，并转化为character\_set\_connection的编码(latin1，所以不用转换）传到服务器端，然后被转化为utf8(表的编码)存入数据库。在最后一步latin1到utf8的转换中, 每个拉丁字符被转换为utf8编码(ascii码大于127的拉丁字符的utf8编码均为2个字节)，如 E4 => C3A4，因此，最后是hex形式为C3A4C2B8C2AD的字节流存入了数据库。 查询: utf8数据C3A4C2B8C2AD从数据库取出后，转为latin1(character\_set\_results) E4B8AD,再转为latin1(character\_set\_connection)传回客户端,再转为latin1(character\_set\_client)输出到屏幕。所以最后客户端输出的字节流hex形式是E4B8AD。由于终端是utf8编码，该字节流被显示为"中" 

<pre class="code">$ cat test1.sh
( echo 'set character_set_client=utf8;' && cat data.sql ) | mysql -utest
mysql -utest test -e 'select title, hex(title) from documents'

$ sh test1.sh
+-------+------------+
| title | hex(title) |
+-------+------------+
| ?     | 3F         |
+-------+------------+
</pre> 插入: 由于character\_set\_client为utf8，在data.sql中，"中"的字节流"E4B8AD"被解释为一个utf8字符，并转化为character\_set\_connection的编码(latin1,转换失败,转换结果为3F）传到服务器端。之后过程同上，最后是hex形式为3F的字节流存入了数据库。 查询 同上，只是最后一步转为utf8输出到屏幕。但3f的utf8编码仍为3F，因此最终输出的字节流为"3F"，显示为"?" 

<pre class="code">$ cat test2.sh
( echo 'set names utf8;' && cat data.sql ) | mysql -utest
mysql -utest test -e 'select title, hex(title) from documents'

$ sh test2.sh
+-------+------------+
| title | hex(title) |
+-------+------------+
| ?     | E4B8AD     |
+-------+------------+
</pre> "set names utf8"将character\_set\_{client,connection,results}均设为utf8 插入: 整个路径全为utf8, 因此不用转换,最后hex形式为E4B8AD的字节流存入数据库 查询: utf8流E4B8AD从数据库数据库取出，转换为latin1(character\_set\_results)，但转换失败，转换为3F，之后不用转换，最后输出到屏幕的流为3F，显示为"?" 

<pre class="code">$ cat test3.sh
( echo 'set names utf8;' && cat data.sql ) | mysql -utest
mysql -utest test -e 'set names utf8;select title, hex(title) from documents'

$ sh test3.sh
+-------+------------+
| title | hex(title) |
+-------+------------+
| 中   | E4B8AD     |
+-------+------------+
</pre> 插入: 同上 查询: 整个过程不用转换，最后输出到屏幕的字节流是"E4B8AD"，显示为"中" 所以最后一种方案为推荐方案 类比 $ cat test.txt 中 字节流hex形式为E4B8AD $ iconv -f latin1 -t utf8 test.txt ??- $ iconv -f latin1 -t utf8 test.txt | od -t x1 0000000 c3 a4 c2 b8 c2 ad 0a 字节流hex形式为C3A4C2B8C2AD 或 在vim中 :e ++enc=latin1 test.txt :set fenc=utf8 :w 三个latin1字符分别被转换为utf8字符, 字节流hex形式变为C3A4C2B8C2AD

 [1]: http://www.bluetwanger.de/blog/2006/11/20/mysql-and-utf-8-no-more-question-marks/